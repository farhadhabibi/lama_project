import { LamaControlCenterPage } from './app.po';

describe('lama-control-center App', () => {
  let page: LamaControlCenterPage;

  beforeEach(() => {
    page = new LamaControlCenterPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
