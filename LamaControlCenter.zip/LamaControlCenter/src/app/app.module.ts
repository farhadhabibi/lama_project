import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router'

import { AppComponent } from './app.component';
import { MyServiceService } from './my-service.service'
import { HomeComponent } from './home/home.component';
import { AssociateComponent } from './associate/associate.component';
import { ReplaceComponent } from './replace/replace.component';
import { HistoryComponent } from './history/history.component';
import { NewComponent } from './new/new.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: 'associate', component: AssociateComponent },
  { path: 'replace', component: ReplaceComponent },
  { path: 'history', component: HistoryComponent },
  { path: 'newLama', component: NewComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AssociateComponent,
    ReplaceComponent,
    HistoryComponent,
    NewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [MyServiceService],
  bootstrap: [AppComponent]
})

export class AppModule { }
