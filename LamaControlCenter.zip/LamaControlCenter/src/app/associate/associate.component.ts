import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'

@Component({
  selector: 'app-associate',
  templateUrl: './associate.component.html',
  styleUrls: ['./associate.component.css']
})
export class AssociateComponent implements OnInit {
 data;
 form: FormGroup;
  constructor() { }

  ngOnInit() {
   
  this.form = new FormGroup({
   lamaId: new FormControl('',Validators.required),
   date: new FormControl('',Validators.required),
   time: new FormControl('', Validators.required),
   location: new FormControl(''),
   billboardId: new FormControl('')
  })

  this.data=[
  {lamaID: 'L123', billboardID: 'B123'},
  {lamaID: 'L234', billboardID: 'B234'},
  {lamaID: 'L345', billboardID: 'B345'},
  {lamaID: 'L456', billboardID: 'B456'}
  ];
  this.onSubmit();
  }

  onSubmit(){
  console.log(this.form.value);
  }

}
