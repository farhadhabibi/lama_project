import { Component } from '@angular/core';
import { MyServiceService } from './my-service.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // students =[];
  // constructor(private myService: MyServiceService){}

  ngOnInit(){

  /* console.log(this.myService.obj); */

  // this.myService.fetchData().subscribe(data => console.log(data));

  }
}
