import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormControl, Validators} from '@angular/forms';


@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {

  data;
  form: FormGroup;

  constructor() { }

  ngOnInit() {
  this.form= new FormGroup({
  lamaId: new FormControl('', Validators.required),
  lamaVersion: new FormControl('', Validators.required),
  manufactureDate: new FormControl('', Validators.required),
  // shipmentDate: new FormControl('', Validators.required),
  shipmentDate: new FormControl('', Validators.required),
  device_status: new FormControl(''),
  last_run_date: new FormControl(new Date()),
  created_date: new FormControl(''),
  last_modified_date: new FormControl(''),
  last_modified_by: new FormControl('')
  });


  this.onSubmit();
  }
  
 onSubmit(){
  console.log(this.form.value);
  }
}
