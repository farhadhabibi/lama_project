import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import 'rxjs/RX';

@Injectable()
export class MyServiceService {

  // private url: string = 'https://jsonplaceholder.typicode.com/posts/1'

  // constructor(private http: Http) { }

  // fetchData(){

  // return this.http.get(this.url)
  //    .map((response: Response) => response.json())
  // }

}
