import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  
  data;
  constructor() { }

  ngOnInit() {
  
  this.data=[
  {lamaID: 'L02123', billboardID: 'B123', location: 'KL', start_date: '20-02-2016', end_date: '03-05-2017'},
  {lamaID: 'L02123', billboardID: 'B234', location: 'KL', start_date: '20-02-2016', end_date: '03-05-2017'},
  {lamaID: 'L02123', billboardID: 'B345', location: 'KL', start_date: '20-02-2016', end_date: '03-05-2017'},
  {lamaID: 'L02123', billboardID: 'B456', location: 'KL', start_date: '20-02-2016', end_date: '03-05-2017'}
  ];


  }

}
