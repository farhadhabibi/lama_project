import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

 
 data;
  constructor() { }

  ngOnInit() {

  this.data=[
  {lamaID: 'L123', status: 'Active', billboardID: 'B123', location: 'KL', last_communication: '20-02-2016 02:30AM', last_data_recieved: '03-02-2017', last_data_captured: '01-02-2017'},
  {lamaID: 'L234', status: 'Inactive', billboardID: 'B234', location: 'KL', last_communication: '20-02-2016 02:30AM', last_data_recieved: '03-02-2017', last_data_captured: '01-02-2017'},
  {lamaID: 'L345', status: 'Active', billboardID: 'B345', location: 'KL', last_communication: '20-02-2016 02:30AM', last_data_recieved: '03-02-2017', last_data_captured: '01-02-2017'},
  {lamaID: 'L456', status: 'Inactive', billboardID: 'B456', location: 'KL', last_communication: '20-02-2016 02:30AM', last_data_recieved: '03-02-2017', last_data_captured: '01-02-2017'},
  {lamaID: 'L456', status: 'Inactive', billboardID: 'B456', location: 'KL', last_communication: '20-02-2016 02:30AM', last_data_recieved: '03-02-2017', last_data_captured: '01-02-2017'}
  ];
 
  }

}
