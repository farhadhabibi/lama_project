import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-replace',
  templateUrl: './replace.component.html',
  styleUrls: ['./replace.component.css']
})
export class ReplaceComponent implements OnInit {
  data;
  form: FormGroup;
  constructor() { }

  ngOnInit() {

  this.form= new FormGroup({
  lamaId: new FormControl('', Validators.required),
  newLamaId: new FormControl('', Validators.required),
  date: new FormControl('', Validators.required),
  time: new FormControl('', Validators.required)
  })

  this.data=[
		{lamaID: 'L123'},
		{lamaID: 'L234'},
		{lamaID: 'L345'},
		{lamaID: 'L456'}
  ];

  this.onSubmit();
  }

  onSubmit(){
  console.log(this.form.value);
  }

}
